# RESCHU-MAAIT — Source Code Guide

A map of every file in `src/reschu/`, what lives inside it, and **where to go to
change specific things**. Read this when you want to adjust a rule, a number, or
a behavior and aren't sure which file to open.

The mental model: the files form layers, from vocabulary at the bottom to the
runnable demo at the top. Each layer only depends on the ones below it.

```
demo.py            <- runs everything, writes the CSVs (top layer)
web/server.py      <- FastAPI: runs the sim, streams state, takes classify actions
web/index.html     <- browser: draws the tactical map, right-click to classify
  engine.py        <- the tick loop that drives one step of the whole sim
    scenario.py    <- builds the starting world (USVs, boats, settings)
    policies.py    <- the USV decision agents (llm / mdp; scripted baseline)
    observation.py <- the truth-free view agents get (hides ground truth)
    assignment.py  <- which agent USV is linked to which boat
    usv_movement.py<- how USVs move (seek, circle, escort, intercept, manual)
    interception.py<- the manual-interception "will I make it?" math
    behaviors.py   <- how BOATS move (their end goals + escort-out routing)
    identification.py <- when/how a boat gets identified (and misidentified)
  models.py        <- the data objects: Grid, Boat, USV, World, CommsSchedule
  types.py         <- the vocabulary: enums + Vec2 geometry (bottom layer)
```

---

## types.py — the vocabulary and geometry

The words the whole system speaks, plus 2-D math. Nothing here "does" anything;
it defines the categories and the point/vector type.

**Contains:**
- `Classification` — the THREE real boat types: civilian, friendly, enemy.
- `Perception` — what the operator SEES: unknown, or one of the three once
  identified. (Kept separate so a boat can never *be* "unknown".)
- `Behavior` — how a boat moves: civilian, aggressive, standoff, friendly.
- `ThreatTier` — L / M / H.
- `threat_for_behavior(behavior, speed)` — the rule mapping behavior+speed to a
  tier (aggressive→H, standoff@8kn→M, standoff@4kn→L).
- `STANDOFF_SPEED_LOW = 4.0`, `STANDOFF_SPEED_MEDIUM = 8.0` — the two standoff
  speeds and which tier each implies.
- `USVMode` — the three control modes: manual / llm / mdp (one per USV per run; a run may mix them). `.is_agent()` = llm or mdp.
- `CommsState` — in_range / near_edge / out_of_range.
- `Vec2` — an (x, y) point/vector with add, subtract, multiply, `length()`,
  `distance_to()`, `normalized()`.

**Go here to change:**
- The threat-tier rule, or the standoff speeds that define Low vs Medium →
  `threat_for_behavior` and the `STANDOFF_SPEED_*` constants.
- Add/rename a classification, behavior, comms state, or mode → the enums.

---

## models.py — the data objects

The "nouns" of the simulation. These are Pydantic models (data + a few helper
methods). This is where most **per-thing settings and state fields** live.

**Contains:**
- `Grid` — width/height of the world; `contains()` and `clamp()` keep points in
  bounds.
- `CommsWindow` / `CommsSchedule` — a USV's comms timeline; `state_at(t)` returns
  the comms state at a given mission time (most-degraded active window wins).
- `Boat` — a contact. Holds:
  - ground truth: `true_class`, `behavior`, `standoff_speed`
  - movement: `position`, `heading`, `start_pos`, `end_goal`, `straight_heading`
  - what the operator sees: `identified`, `perceived_class`, `threat_tier`
  - ID accounting: `id_attempts`, `is_correctly_identified()`
  - escort state: `being_escorted`, `left_grid`, `escort_start_min`,
    `escort_end_min`
  - methods: `speed_knots()` (per-behavior speed), `identify(as_class=None)`
    (records a correct or wrong ID; wrong keeps true behavior).
- `USV_BASE_SPEED_KNOTS = 12.0` — the one base speed all USVs share.
- `USV` — a vehicle. Holds:
  - `position`, `heading`, `start_pos`, `mode`, `manual_heading`
  - `operator_speed_knots` (manual override), `misid_rate` (agent error rate)
  - `attempted_boat_ids`, `assigned_target_id`, `intercept_target_id`
  - `circling_since_min`, `circle_events`
  - methods: `effective_speed_knots()`, `set_operator_speed()`, `update_comms()`
- `World` — everything at once: grid, usvs, boats, `mission_time_min`; `usv(id)`
  and `boat(id)` lookups.

**Go here to change:**
- The USV base speed → `USV_BASE_SPEED_KNOTS`.
- Boat speeds by behavior → `Boat.speed_knots()`.
- What a correct vs wrong identification does → `Boat.identify()`.
- Add a new field to a boat or USV (e.g. a new setting to record) → the `Boat`
  or `USV` class.
- Comms "most-degraded wins" logic or the in-range default → `CommsSchedule.state_at`.

---

## behaviors.py — how BOATS move

One place for all autonomous boat motion. Every boat heads toward an **end goal**
chosen by its type, and picks a new one on arrival. Also holds the special
"escort me off the grid" routing.

**Contains:**
- `UNITS_PER_KNOT_MIN = 1.0` — the knots→grid-units conversion (shared scale for
  boats AND usvs).
- `_step_distance`, `_move_towards` — movement helpers.
- Goal rules, one per behavior:
  - `_goal_aggressive` — attack the nearest USV OR friendly boat, but only once
    it comes within `AGGRESSIVE_DETECTION_RANGE` (6.0) — it must "see" a target
    first. Beyond that range it SEEKS (random wander). Gives up and re-seeks if a
    locked target moves back out of range.
  - `_goal_standoff` — a random point on a random grid edge, weighted toward
    edges away from the boat (heads outward; varied approach angles, not only
    diagonal). NOTE: standoff boats don't yet avoid the USVs while retreating —
    deliberately deferred until the USVs become mobile (they're stationary in the
    centre now and the boats already head outward, so avoidance would be dormant).
  - `_goal_civilian` — random walk: a random direction + distance each leg; wide
    reach + commit-to-goal so it roams across much of the grid.
  - `_goal_friendly` — zigzag TRANSIT: a stable base course with a small
    non-accumulating heading wobble; travels across the grid and EXITS at the far
    edge (no wall-bounce). On exit the engine despawns it and spawns a new
    friendly (B7, B8, ...) from a random edge, keeping the friendly count constant.
- `choose_goal` — dispatches to the right rule.
- `ESCORT_DANGER_RADIUS = 12.0` — how far an escorted boat stays from threats.
- `_nearest_edge_point`, `_threat_positions`, `escort_exit_step` — the escort-out
  routing: head to the nearest edge while veering away from enemy/unknown boats.
- `step_boat` — the ONE function the engine calls per boat per tick. Handles: left
  the grid already? being escorted? otherwise normal goal-seeking.
- `_on_boundary` — detects when a boat reaches the edge (used to mark it exited).

**Go here to change:**
- What "end goal" each boat type heads for → the `_goal_*` functions.
- How far escorted boats keep from threats → `ESCORT_DANGER_RADIUS`.
- How escorted boats route out (e.g. always exit a specific side) →
  `escort_exit_step` / `_nearest_edge_point`.
- The knots→units scale (physical calibration) → `UNITS_PER_KNOT_MIN`.

---

## identification.py — when a boat gets identified (and misidentified)

The bridge from a boat's truth to what the operator sees.

**Contains:**
- `IDENTIFY_RANGE = 6.0` — how close (grid units) a USV must be to identify.
- `_in_range` — the proximity check.
- `_wrong_class` — picks a random wrong label for a misidentification.
- `_needs_identification` — a boat is eligible unless it's already CORRECTLY
  identified (so misidentified boats can still be corrected).
- `auto_identify(world, rng)` — agent USVs identify boats in range; may be wrong
  per each USV's `misid_rate`; a USV won't re-roll a boat it already tried.
- `manual_identify(world, usv_id, boat_id)` — the operator action; always correct
  for now; requires the USV to be manual and in range.

**Go here to change:**
- The identification range → `IDENTIFY_RANGE`.
- How misidentification works (probability model, how the wrong label is chosen)
  → `auto_identify` and `_wrong_class`.
- Whether manual/operator IDs can be wrong too → `manual_identify`.
- Whether a USV can re-attempt its own boat → the `attempted_boat_ids` check in
  `auto_identify`.

---

## usv_movement.py — how USVs move

The vehicle-side counterpart to behaviors.py. All USV motion and the engagement
lifecycle live here.

**Contains:**
- `usv_step_distance`, `move_towards`, `has_arrived` — basic travel toward a point.
- `nearest_unknown_boat`, `agent_seek_step` — go to the nearest unidentified boat.
- Engagement constants:
  - `CIRCLE_RADIUS = 4.0` — how far a USV holds while circling an enemy.
  - `CIRCLE_RATE = 1.2` — how fast it orbits.
  - `ESCORT_OFFSET = 3.0` — how far behind an escorted boat it keeps station.
  - `CIRCLE_DURATION_MIN = 2.0` — how long it circles before moving on.
- `circle_step`, `escort_step` — the two engagement movements.
- `assigned_agent_step(usv, world, dt, now_min)` — **the main agent brain.** Per
  tick: approach the assigned boat → once identified, circle (timed) a perceived
  enemy or escort a perceived friendly/civilian → release when done. Records
  circle/escort timestamps.
- `_release` — ends an engagement, logs the circle window, clears the link.
- `manual_straight_step`, `manual_step` — manual USVs: straight-line travel, or an
  operator interception course that stops at ID range.
- (`agent_step` is an older non-assignment version, kept for reference/tests.)

**Go here to change:**
- Circle radius / speed / **2-minute duration** → `CIRCLE_RADIUS`, `CIRCLE_RATE`,
  `CIRCLE_DURATION_MIN`.
- Escort standoff distance → `ESCORT_OFFSET`.
- The agent decision logic (what a USV does after identifying) →
  `assigned_agent_step`.
- What manual USVs do by default → `manual_straight_step` / `manual_step`.

---

## policies.py — the USV decision agents (scripted / LLM / MDP)

The "brain" seam. An AGENT-mode USV is driven by a *policy* that makes the
choices (which boat, speed, direction, when to identify, circle vs escort); the
*mechanics* stay in usv_movement.py. This is where trained agents plug in.

**Contains:**
- `Policy` — the base class. Real agents override `act(usv, obs, dt)`, which is
  handed ONLY the truth-free `Observation` — never the `World`. The base
  `decide()` builds the observation and calls `act()`. Because `act()` has no
  `world` parameter, an agent's decision code *cannot* reach ground truth (true
  class/behavior/tier) even by accident — the world object is not in scope.
- `ScriptedPolicy` — the rule-based baseline (works today). As an INTERNAL
  mechanics component (not an agent under study), it overrides `decide()`
  directly so it can use the movement helpers (which take `world` to carry out
  motion). It still reads no ground truth — the movement layer uses perceived
  class only.
- `LLMPolicy` — LLM-driven agent, **stub, not trained/connected yet**; currently
  falls back to scripted, with a TODO marking where the real LLM call goes
  (implement `act(usv, obs, dt)`).
- `MDPPolicy` — MDP-driven agent, **stub, not trained/connected yet**; same
  fallback + TODO.
- `policy_for(usv)` — returns the policy for a USV based on its `mode` (llm/mdp).

**Ground-truth hardening:** the guarantee is structural, not just conventional.
`act()` never receives `world`, so a future LLM/MDP agent physically cannot see a
boat's true identity — it can only build its decision from the perceived
`Observation`. Enforced by tests (`test_agent_act_signature_excludes_world`,
`test_observation_object_has_no_world_or_truth`).

**Go here to change:**
- Implement a real LLM or MDP agent → override `act(usv, obs, dt)` (NOT `decide`)
  so it reads only the truth-free observation; drop the fallback `decide`.
- Add a new kind of agent → subclass `Policy`, add a mode to `USVMode` (types.py)
  and to the `_POLICIES` map.
- Which mode a USV uses → set `mode=` (USVMode.MANUAL / LLM / MDP) on the USV in scenario.py.

---

## web/ — the operator-console UI (simplified scenario)

The first browser UI. `server.py` (FastAPI) runs the simulation server-side and
streams each tick's state to the browser over a WebSocket; `index.html` draws the
tactical map on a canvas and sends operator classify actions back. Truth-free by
construction: the operator map is fed perceived data only; ground truth is sent
separately (nested under each boat's `truth`) purely for a researcher side panel.

**Contains:**
- `web/server.py` — the FastAPI app: `/` serves the page, `/ws` runs the engine
  (via its `on_tick` hook) and streams state; handles the `classify` action by
  calling `manual_identify`.
- `web/index.html` — the canvas map, contact markers by perceived class, the
  identification rings, the right-click classify menu, and the operator/researcher
  side panels.

**Run:** `uv pip install -e ".[web]"` then
`uv run uvicorn reschu.web.server:app --reload` → http://127.0.0.1:8000

**Go here to change:**
- What the browser receives → `_state_payload` / `_boat_payload` in server.py.
- The map look, marker shapes, or the classify menu → index.html.
- A new operator action → add a branch in the `/ws` receive loop + a handler.

---

## observation.py — the truth-free view agents get

Enforces the rule that agents (LLM, MDP, and the scripted baseline) decide from
**perceived information only** — never a boat's ground truth. Ground truth stays
engine-side, used only to reveal identity through identification and to score
results.

**Contains:**
- `BoatView` — a boat as an agent perceives it: id, position, distance,
  identified?, perceived_class, threat_tier, escort/left-grid flags. It
  deliberately has NO `true_class`, `behavior`, or `standoff_speed` fields.
- `SelfView` — the USV's own state (position, speed, comms, assignment, etc.).
- `Observation` — the whole truth-free snapshot a USV's agent sees, with helpers
  like `unidentified()`, `perceived_enemies()`, `perceived_nonenemies()`.
- `observe(usv, world, now_min)` — the ONLY bridge from the full world (which
  holds truth) to an agent; builds the filtered view.

**Go here to change:**
- What an agent is allowed to perceive (add/remove an observed field) → `BoatView`
  / `SelfView` / `observe`. (Adding a ground-truth field here would break the
  boundary — don't.)

---

## assignment.py — which USV is linked to which boat

Decides the USV→boat links (the line drawn in the mockup). Selection is closest
first, aggressiveness as the tie-break, and links are exclusive.

**Contains:**
- `_is_aggressive`, `_assigned_boat_ids`, `_pick_boat_for` — helpers.
- `assign_all(world)` — the START-of-run assignment (each agent takes its best
  available boat).
- `reassign_free_agents(world)` — gives a new boat to any agent that just finished
  an engagement (prefers boats still needing work). Called every tick by the
  engine.
- `_pick_unworked_boat` — the "next boat that still needs work" picker.
- `reassign_usv(world, usv_id)` — the OPERATOR double-click action: drop the
  current boat, take another available one.

**Go here to change:**
- The selection rule (closest vs aggressiveness weighting) → `_pick_boat_for`
  and `_pick_unworked_boat` (the `key=` sort).
- Whether/how USVs re-assign after finishing a boat → `reassign_free_agents`.
- What double-click does → `reassign_usv`.

---

## interception.py — the manual "will I make it?" math

The operator-driven interception feature. Pure geometry + a couple of operator
actions.

**Contains:**
- `InterceptResult` — the answer object: feasible?, point, time, speeds, reason.
- `_boat_velocity`, `_solve_intercept_time` — the moving-target interception
  quadratic.
- `evaluate_intercept(usv, boat, world, speed)` — can this USV catch this boat at
  this speed? Returns an `InterceptResult`.
- `minimum_intercept_speed_knots(...)` — the lowest speed that works (advisory).
- `commit_intercept(world, usv_id, boat_id, speed)` — operator action: point a
  manual USV at a boat at a chosen speed; it will steer there and stop at ID
  range. Returns the feasibility.
- `cancel_intercept(world, usv_id)` — clear it, back to straight-line.

**Go here to change:**
- The feasibility rules (e.g. allow intercept off-grid) → `evaluate_intercept`.
- What committing an interception does → `commit_intercept`.

---

## engine.py — the tick loop

The heart that advances the whole simulation one step. Everything above is
orchestrated here.

**Contains:**
- `SimulationEngine.__init__(world, dt_min, seed, assign_at_start)` — sets up the
  run, captures USV start positions, does the initial assignment.
- `SimulationEngine.tick()` — ONE simulated step, in order:
  1. advance mission time
  2. move every boat (and record escort-exit times)
  3. move every USV (agents work assignments; manuals go straight/intercept)
  4. re-assign any freed agents
  5. update comms states
  6. run auto-identification (with misID)
- `run(...)` — the async loop that calls `tick()` repeatedly (with the `on_tick`
  hook the demo/CSV and a future web UI use).
- `stop()`.

**Go here to change:**
- The ORDER of operations each tick, or to add a new per-tick step → `tick()`.
- The default timestep, seed, or whether to assign at start → `__init__`.
- Real-time pacing / the broadcast hook → `run()`.

---

## scenario.py — the starting world (the "settings")

Builds the initial `World`: the USVs, the boats, and all their per-run settings.
**This is the file you edit to change a run's setup.**

**Contains:**
- `_schedule(...)` — a shorthand for building a comms schedule.
- `simple_world()` — the simplified "bit by bit" scenario: 6 boats (known/unknown
  enemies at low/high tier, a friendly, a civilian) and 2 STATIONARY centre USVs
  (one manual, one agent). It's the default; `RESCHU_SCENARIO=demo` runs the full
  4-USV world instead.
- `demo_world()` — creates the grid (100×60), the 4 USVs (modes, start positions,
  manual headings, comms schedules, misID rates), and the 5 boats (types,
  behaviors, standoff speeds, start positions).

**Go here to change:**
- Grid size; how many USVs/boats; their start positions, modes, speeds,
  behaviors, comms schedules, misID rates → all inside `demo_world()`.
- This is the "settings screen" in code form until a real config/UI exists.

---

## demo.py — runs it and writes the CSVs

The top-level runnable. Builds the demo world, runs the engine, prints the
mission log, and writes the two result files.

**Contains:**
- `CSV_PATH`, `USV_CSV_PATH`, `COMBINED_CSV_PATH` — output file locations. The
  combined file merges boats and USVs into one long file with a `row_type`
  column ("boat"/"usv") for easy tracking/filtering.
- `CSV_COLUMNS`, `USV_CSV_COLUMNS` — the columns in each result file.
- `_rows_for_tick` — builds one boat-CSV row per boat per tick (with the
  blank-until-applicable rule for ID and escort cells).
- `_usv_activity`, `_usv_rows_for_tick` — builds the USV-CSV rows (activity label,
  target, distances, circling time).
- `_true_class_label` — formats `enemy (H)` etc.
- `_summary`, `_boat_lines` — the console printout.
- `main()` — orchestrates the run, prints the circle/escort timing summaries, and
  writes both CSVs.

**Go here to change:**
- What columns the CSVs have, or how a cell is formatted (e.g. blank vs value) →
  `CSV_COLUMNS` / `USV_CSV_COLUMNS` and the `_rows_for_tick` / `_usv_rows_for_tick`
  builders.
- The mission length or timestep for the demo run → the `SimulationEngine(...)`
  and `engine.run(...)` calls in `main()`.
- The console output → `_summary`, `_boat_lines`, and the print blocks in `main()`.

---

## Quick "I want to change X" index

| I want to change... | File | What to edit |
| --- | --- | --- |
| Identification range (6 units) | identification.py | `IDENTIFY_RANGE` |
| Circle duration (2 min) | usv_movement.py | `CIRCLE_DURATION_MIN` |
| Circle radius / orbit speed | usv_movement.py | `CIRCLE_RADIUS`, `CIRCLE_RATE` |
| Escort standoff distance | usv_movement.py | `ESCORT_OFFSET` |
| Escort threat-avoidance distance | behaviors.py | `ESCORT_DANGER_RADIUS` |
| USV base speed (12 kn) | models.py | `USV_BASE_SPEED_KNOTS` |
| Boat speeds by type | models.py | `Boat.speed_knots()` |
| Threat-tier rule / standoff speeds | types.py | `threat_for_behavior`, `STANDOFF_SPEED_*` |
| A boat's end-goal behavior | behaviors.py | the `_goal_*` functions |
| Misidentification behavior | identification.py | `auto_identify`, `_wrong_class` |
| A USV's misID rate (per run) | scenario.py | `misid_rate=` on the USV |
| Grid size / who starts where | scenario.py | `demo_world()` |
| Assignment selection rule | assignment.py | `_pick_boat_for` / `_pick_unworked_boat` |
| What each tick does, in order | engine.py | `tick()` |
| Timestep / mission length | scenario.py + demo.py | engine calls |
| CSV columns / blank-cell rules | demo.py | `*_COLUMNS`, `_rows_for_tick` |
| Which mode a USV runs (manual/llm/mdp) | scenario.py | `mode=` on the USV |
| Implement a real LLM / MDP agent | policies.py | override `LLMPolicy` / `MDPPolicy` `.act(usv, obs, dt)` |
| Which scenario the demo runs | env var | `RESCHU_SCENARIO=simple` or `demo` |
| Bernoulli ID probability (per USV) | scenario.py | `id_probability=` on the USV |
| Make a USV stationary | scenario.py | `stationary=True` on the USV |
| Civilian random-walk / friendly zigzag | behaviors.py | `_goal_civilian` / `_goal_friendly` |
| Interception feasibility rules | interception.py | `evaluate_intercept` |

## Elimination mechanics (added)

- **USV in an aggressive boat's danger zone** (`DANGER_ZONE_RADIUS = 6.0`, engine.py)
  → the USV is eliminated and removed from the world (disappears). Applies to all
  USVs (manual + agents). Checked each tick in `_eliminate_usvs_in_danger`.
- **Enemy after circling** → once a USV circles a perceived enemy for
  `CIRCLE_DURATION_MIN` (defined as `CIRCLE_DURATION_REAL_SEC = 10.0` real seconds,
  converted via the playback ratio → 2.0 sim-min at 12x), the enemy is eliminated
  (`left_grid = True`, `eliminated = True`). The circle TRACKS the moving boat
  (circle centre = boat's current position each tick), so the boat can't escape.
- **Escorted civilian/friendly at the edge** → disappears (leaves grid) as before.
- **Distance chain:** ID range 7.5 > circle radius 7.0 > danger zone 6.0. The USV
  must ID (within 7.5) before it can circle (at 7.0), and 7.0 keeps it outside the
  6.0 danger zone so circling a (non-aggressive-adjacent) enemy is safe.
- **Simple scenario now has 4 USVs:** USV-1 manual, USV-2 LLM, USV-3 MDP, USV-4 LLM.

## Recording & replay (added)

Two independent recording features in the web layer:

- **Video recording** (`index.html`, marked `VIDEO RECORDING`): a `REC` button records the MAP CANVAS directly (canvas.captureStream) to a downloadable `.webm` — NO screen-share prompt or permission dialog. Arm-then-auto-start: click once to arm, recording begins automatically when the sim starts. Captures the map only; side panels live in the DVR replay. Remove by deleting the marked block.
- **Data-replay DVR** (`server.py`, marked `DATA-REPLAY DVR`; `replay.html`): every
  run auto-logs each tick's state to `recordings/reschu-recording-*.json` on the
  server (no user action). The `/replay` page lists recordings and plays them back
  with play/pause, step, scrub, and 0.25x-8x speed — reconstructing the full UI
  from the data. Endpoints: `/recordings` (list), `/recordings/{name}` (fetch or
  download JSON), `/replay` (viewer). The DVR is the durable, study-oriented
  record; the video is for sharing.

## Scenario configuration / settings page (added)

Before starting a run, the scenario can be configured on a settings page instead
of being hardcoded.

- `scenario.py` → `world_from_config(cfg)` builds a `World` from a settings dict
  (grid, per-boat type/behavior/tier/start/goal/known, per-USV mode+start).
  `default_config()` returns the dict that reproduces `simple_world()`.
- `web/settings.html` → the "ADMINISTRATOR — Scenario Configuration" page
  (Scenario Setup, USV Control, Boats Panel), reached from the `⚙ SETTINGS` link
  on the main screen. It POSTs the config and returns to the sim.
- `web/server.py` → holds the current config in `_CURRENT_CONFIG`; endpoints
  `/settings` (page), `GET /config` (current), `POST /config` (save). The `/ws`
  handler builds the world via `world_from_config(_CURRENT_CONFIG)`.
- Scope: only settings the sim supports (counts, mission duration, boat setup,
  USV mode+start). The mockup's timed mode-sequence and comms schedule are NOT
  built (they need engine features that don't exist yet).
