"""Identification rules — the bridge from a boat's true type to what the
operator perceives.

Rules:
  * A USV must be within IDENTIFY_RANGE of a boat to identify it at all.
  * AGENT-mode USVs identify eligible nearby boats automatically each tick, but
    may MISIDENTIFY according to their per-USV `misid_rate` (e.g. 0.30 = wrong
    30% of the time). A wrong identification applies a random wrong class; the
    boat keeps its true behavior and can be re-identified later.
  * MANUAL-mode USVs identify only on an explicit operator action, and (for now)
    are always correct.

"Correctly identified" boats are left alone. A boat that was *mis*identified is
still eligible for another attempt — by the same USV coming back, or any other —
so the label can be corrected before the mission ends. Every attempt is counted
on the boat (`id_attempts`), which is the research measure of interest.
"""

from __future__ import annotations

import random

from .models import USV, World
from .types import Classification, Perception, USVMode, Vec2

# Base (Small-map) identification range in grid cells. The ACTUAL range on a map
# is this times grid.range_scale (Small x1 = 2.0, Medium x2 = 4.0, Large x3 = 6.0),
# so it stays the same fraction of each map. Use identify_range(grid) to get the
# scaled value rather than this constant directly.
IDENTIFY_RANGE = 2.0


def identify_range(grid) -> float:
    """Scaled identification range for the given grid (Small x1, Med x2, Lg x3)."""
    return IDENTIFY_RANGE * grid.range_scale


def _in_range(usv: USV, boat_pos: Vec2, grid) -> bool:
    return usv.position.distance_to(boat_pos) <= identify_range(grid)


def _wrong_class(true_class: Classification, rng: random.Random) -> Perception:
    """Pick a random class that is NOT the boat's true class."""
    options = [c for c in Classification if c is not true_class]
    choice = rng.choice(options)
    return Perception.from_classification(choice)


def _needs_identification(boat) -> bool:
    """Eligible for an ID attempt if it has never been correctly identified.
    (Unidentified, or previously MISidentified, are both still eligible.)"""
    return not boat.is_correctly_identified()


def auto_identify(world: World, rng: random.Random | None = None) -> list[str]:
    """Agent-mode USVs attempt to identify boats in range that are not yet
    correctly identified. Each attempt may be wrong per the USV's misid_rate.
    Returns the list of boat ids attempted this call.

    A USV does not re-attempt a boat it has already tried (tracked on the USV),
    so it "moves on" after an attempt rather than re-rolling every tick. A
    misidentified boat can still be corrected by a DIFFERENT USV that comes in
    range. `rng` makes misidentification reproducible.
    """
    if rng is None:
        rng = random.Random()

    attempted: list[str] = []
    for usv in world.usvs:
        if not usv.mode.is_agent():
            continue
        for boat in world.boats:
            if not _needs_identification(boat):
                continue
            if boat.id in usv.attempted_boat_ids:
                continue  # this USV already tried this boat; don't re-roll
            if not _in_range(usv, boat.position, world.grid):
                continue
            # Bernoulli trial: each in-range boat gets an independent coin-flip.
            # It is only identified this tick if the flip succeeds (prob =
            # usv.id_probability); otherwise it remains eligible for later ticks.
            if rng.random() >= usv.id_probability:
                continue
            usv.attempted_boat_ids.append(boat.id)
            # roll for a misidentification
            if rng.random() < usv.misid_rate:
                boat.identify(as_class=_wrong_class(boat.true_class, rng))
            else:
                boat.identify()  # correct
            attempted.append(boat.id)
    return attempted


def manual_identify(
    world: World, usv_id: str, boat_id: str, as_class: Perception | None = None
) -> bool:
    """Operator action: identify `boat_id` using manual USV `usv_id`.

    Succeeds only if the USV is manual and within range. `as_class` is the class
    the operator picked from the classify menu (Unknown is treated as no-op /
    leaves it unidentified); if None, the identification is recorded as correct
    (the boat's true class). The operator CAN pick the wrong class — the boat
    keeps its true behavior, and the mistake is counted like any misID. Returns
    True on success."""
    usv = world.usv(usv_id)
    boat = world.boat(boat_id)
    if usv is None or boat is None:
        return False
    if usv.mode is not USVMode.MANUAL:
        return False
    if not _in_range(usv, boat.position, world.grid):
        return False
    if as_class is Perception.UNKNOWN:
        return False  # "Unknown" = operator declines to classify -> no-op
    boat.identify(as_class=as_class)
    return True
