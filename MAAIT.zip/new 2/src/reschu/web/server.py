"""FastAPI web layer for the simplified RESCHU-MAAIT scenario.

Runs the simulation server-side and streams each tick's state to the browser
over a WebSocket; the browser draws the tactical map and sends operator actions
(classify a contact via the manual USV) back.

Truth boundary: the browser is sent BOTH a truth-free operator view (what the
console shows) and, separately flagged, the ground truth — the latter only so the
researcher can see it in a side panel. The operator-facing map uses perceived
data only. The engine stays authoritative on the server.

Run:  uvicorn reschu.web.server:app --reload
      then open http://127.0.0.1:8000
"""

from __future__ import annotations

import asyncio
from pathlib import Path

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse, JSONResponse

from ..assignment import reassign_usv
from ..behaviors import UNITS_PER_KNOT_MIN
from ..engine import SimulationEngine, danger_zone_radius
from ..identification import identify_range, manual_identify
from ..scenario import simple_world, world_from_config, default_config
from ..types import Perception, Vec2

app = FastAPI(title="RESCHU-MAAIT")

# How long a web mission runs, in SIMULATION minutes. The run ends (clock freezes
# and a "mission complete" notice is sent) once the sim clock reaches this. At the
# How long a web mission runs, in SIMULATION minutes. The run ends (clock freezes
# and a "mission complete" notice is sent) once the sim clock reaches this. The
# slider runs the sim in real time at 1x, so at 1x a 20-minute mission is 20
# minutes of real watching (the operator can speed up with the slider).
MISSION_LENGTH_MIN = 20.0

_HTML = (Path(__file__).parent / "index.html").read_text()
_REPLAY_HTML = (Path(__file__).parent / "replay.html").read_text()
_SETTINGS_HTML = (Path(__file__).parent / "settings.html").read_text()
_GRIDREF_HTML = (Path(__file__).parent / "gridref.html").read_text()

# ---- DATA-REPLAY DVR: where session recordings are stored on the server ---- #
import json as _json
import random as _random
from . import messages as _messages
from datetime import datetime as _dt

RECORDINGS_DIR = Path("recordings")


RESULTS_DIR = Path("results")


def _write_results_csv(world, config: dict,
                       timestep_log: list | None = None,
                       operator_log: list | None = None) -> dict | None:
    """Write the results CSVs for a finished run (regardless of the REC button):
      * results-{ts}-contacts.csv  : one row per boat.
      * results-{ts}-summary.csv   : one row for the whole mission.
      * results-{ts}-timesteps.csv : one row per USV per tick (mode + activity).
      * results-{ts}-operator.csv  : one row per operator action.
    Returns a dict of the file names written, or None."""
    import csv
    from ..types import threat_for_behavior

    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    ts = _dt.now().strftime("%Y-%m-%d_%H-%M-%S")
    contacts_name = f"results-{ts}-contacts.csv"
    summary_name = f"results-{ts}-summary.csv"

    boats = world.boats
    # ---- per-contact rows ----
    contact_fields = [
        "boat_id", "true_class", "behavior", "true_tier",
        "identified", "perceived_class", "correct", "id_attempts",
        "first_identified_min", "outcome", "escort_start_min", "escort_end_min",
    ]
    rows = []
    for b in boats:
        from ..types import Classification
        if b.true_class is Classification.ENEMY:
            try:
                tt = threat_for_behavior(b.behavior, b.speed_knots())
                true_tier = tt.value if tt else ""
            except Exception:
                true_tier = ""
        else:
            true_tier = ""   # tier only meaningful for enemies
        outcome = ("eliminated" if b.eliminated
                   else "exited" if b.left_grid
                   else "on_grid")
        rows.append({
            "boat_id": b.id,
            "true_class": b.true_class.value,
            "behavior": b.behavior.value,
            "true_tier": true_tier,
            "identified": int(b.identified),
            "perceived_class": b.perceived_class.value if b.identified else "",
            "correct": int(b.is_correctly_identified()) if b.identified else "",
            "id_attempts": b.id_attempts,
            "first_identified_min": b.first_identified_min if b.first_identified_min is not None else "",
            "outcome": outcome,
            "escort_start_min": b.escort_start_min if b.escort_start_min is not None else "",
            "escort_end_min": b.escort_end_min if b.escort_end_min is not None else "",
        })
    with (RESULTS_DIR / contacts_name).open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=contact_fields)
        w.writeheader()
        w.writerows(rows)

    # ---- per-run summary ----
    n_boats = len(boats)
    identified = [b for b in boats if b.identified]
    correct = [b for b in identified if b.is_correctly_identified()]
    incorrect = [b for b in identified if not b.is_correctly_identified()]
    id_times = [b.first_identified_min for b in identified if b.first_identified_min is not None]
    usvs = world.usvs
    usvs_eliminated = sum(1 for u in usvs if getattr(u, "eliminated", False) or u.left_grid)
    # The distinct control modes each USV was CONFIGURED to use over the mission
    # (from its timeline), not a meaningless end-of-mission snapshot. Per-USV,
    # per-tick modes are in the timesteps CSV.
    cfg_modes = set()
    for uc in (config.get("usvs") or []):
        tl = uc.get("timeline") or []
        if tl:
            cfg_modes.update(str(blk.get("mode", "")).lower() for blk in tl)
        elif uc.get("mode"):
            cfg_modes.add(str(uc["mode"]).lower())
    modes_used = sorted(m for m in cfg_modes if m)

    import statistics
    mean_id = round(statistics.mean(id_times), 3) if id_times else ""
    median_id = round(statistics.median(id_times), 3) if id_times else ""

    summary = {
        "timestamp": ts,
        "num_usvs": len(usvs),
        "num_boats": n_boats,
        "grid_w": int(world.grid.width),
        "grid_h": int(world.grid.height),
        "mission_minutes": config.get("mission_minutes", ""),
        "usv_modes_configured": "|".join(modes_used),
        "contacts": n_boats,
        "identified": len(identified),
        "correct": len(correct),
        "incorrect": len(incorrect),
        "pct_correct": round(100 * len(correct) / len(identified), 1) if identified else "",
        "total_id_attempts": sum(b.id_attempts for b in boats),
        "mean_time_to_id_min": mean_id,
        "median_time_to_id_min": median_id,
        "usvs_lost": usvs_eliminated,
    }
    with (RESULTS_DIR / summary_name).open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(summary.keys()))
        w.writeheader()
        w.writerow(summary)

    out_names = {"contacts": contacts_name, "summary": summary_name}

    # ---- per-USV per-tick timestep log ----
    if timestep_log:
        ts_name = f"results-{ts}-timesteps.csv"
        ts_fields = ["mission_min", "usv_id", "mode", "x", "y",
                     "speed_knots", "comms_state", "fuel_pct",
                     "assigned_target", "activity"]
        with (RESULTS_DIR / ts_name).open("w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=ts_fields)
            w.writeheader()
            w.writerows(timestep_log)
        out_names["timesteps"] = ts_name

    # ---- operator action log ----
    if operator_log:
        op_name = f"results-{ts}-operator.csv"
        op_fields = ["mission_min", "usv_id", "usv_mode", "action", "detail"]
        with (RESULTS_DIR / op_name).open("w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=op_fields)
            w.writeheader()
            w.writerows(operator_log)
        out_names["operator"] = op_name

    return out_names


def _save_recording(frames: list) -> str | None:
    """Write a session's per-tick frames to a JSON file on the server and return
    its filename. Each frame is a truth-free-plus-researcher state payload (the
    same data the browser was sent), so the run can be replayed exactly."""
    if not frames:
        return None
    RECORDINGS_DIR.mkdir(parents=True, exist_ok=True)
    ts = _dt.now().strftime("%Y-%m-%d_%H-%M-%S")
    name = f"reschu-recording-{ts}.json"
    payload = {
        "version": 1,
        "created": ts,
        "dt_min": 0.1,
        "frame_count": len(frames),
        "frames": frames,
    }
    (RECORDINGS_DIR / name).write_text(_json.dumps(payload))
    return name
# --------------------------------------------------------------------------- #


@app.get("/")
async def index() -> HTMLResponse:
    return HTMLResponse(_HTML)


# ---- SCENARIO CONFIG (settings page) -------------------------------------- #
# The current scenario config. Starts as the default (reproduces simple_world);
# the settings page overwrites it, and the next simulation run uses it.
_CURRENT_CONFIG: dict = default_config()
if "mission_minutes" in _CURRENT_CONFIG:
    MISSION_LENGTH_MIN = float(_CURRENT_CONFIG["mission_minutes"])


@app.get("/settings")
async def settings_page() -> HTMLResponse:
    return HTMLResponse(_SETTINGS_HTML)


@app.get("/static/video/{name}")
async def video_file(name: str):
    from fastapi.responses import Response, FileResponse
    # only serve known camera clips
    types = ["civilian","friendly","low_enemy","medium_enemy","high_enemy"]
    scenarios = ["front","crossing","away","behind","behind_away","side_crossing","behind_crossing","side_approaching","side_away"]
    safe = {f"{t}_{s}" for t in types for s in scenarios}
    if name not in safe:
        return Response(status_code=404)
    path = Path(__file__).parent / "static" / "videos" / f"{name}.mp4"
    if not path.exists():
        return Response(status_code=404)
    # FileResponse streams the file and supports HTTP Range requests, which the
    # browser's <video> element needs — a plain full-body Response is rejected
    # with MEDIA_ERR_SRC_NOT_SUPPORTED for streaming playback.
    return FileResponse(path, media_type="video/mp4")


@app.get("/static/grid/{size}")
async def grid_image(size: str):
    from fastapi.responses import Response
    if size not in ("small", "medium", "large"):
        return Response(status_code=404)
    path = Path(__file__).parent / "static" / f"grid_{size}.png"
    if not path.exists():
        return Response(status_code=404)
    return Response(path.read_bytes(), media_type="image/png")


@app.get("/gridref")
async def gridref_page() -> HTMLResponse:
    """Standalone labelled grid, opened from the settings page in a new window so
    admins can see where (x, y) start positions land."""
    return HTMLResponse(_GRIDREF_HTML)


@app.get("/config")
async def get_config() -> JSONResponse:
    return JSONResponse(_CURRENT_CONFIG)


@app.post("/config")
async def set_config(cfg: dict) -> JSONResponse:
    """Save a new scenario config from the settings page.

    Enforces the hard caps server-side (not just in the browser): at most
    MAX_USVS USVs and MAX_BOATS boats. Mission duration is not capped (any
    positive length is allowed). The grid is fixed and cannot be changed here.
    """
    global _CURRENT_CONFIG, MISSION_LENGTH_MIN

    # ---- hard caps (mirror the settings-page limits) ----
    MAX_USVS, MAX_BOATS = 8, 15
    if isinstance(cfg.get("usvs"), list):
        cfg["usvs"] = cfg["usvs"][:MAX_USVS]
    if isinstance(cfg.get("boats"), list):
        cfg["boats"] = cfg["boats"][:MAX_BOATS]
    try:
        mm = float(cfg.get("mission_minutes", 60.0))
        cfg["mission_minutes"] = max(1.0, mm)   # floor at 1 min, no upper cap
    except (TypeError, ValueError):
        cfg["mission_minutes"] = 60.0
    # grid is limited to the three offered map sizes; anything else snaps to the
    # nearest offered size so start positions stay meaningful. Map sizes are
    # abstract grid sizes; boat/USV speeds are tuned for pace, not real distance.
    _MAP_SIZES = {(40, 25), (80, 50), (120, 75)}
    g = cfg.get("grid") or {}
    try:
        gw, gh = int(g.get("width", 120)), int(g.get("height", 75))
    except (TypeError, ValueError):
        gw, gh = 120, 75
    if (gw, gh) not in _MAP_SIZES:
        # pick the offered size whose width is closest
        gw, gh = min(_MAP_SIZES, key=lambda s: abs(s[0] - gw))
    cfg["grid"] = {"width": float(gw), "height": float(gh)}

    _CURRENT_CONFIG = cfg
    try:
        MISSION_LENGTH_MIN = float(cfg.get("mission_minutes", MISSION_LENGTH_MIN))
    except (TypeError, ValueError):
        pass
    # validate by attempting to build the world; report any error
    try:
        world_from_config(cfg)
    except Exception as e:  # noqa: BLE001
        return JSONResponse({"ok": False, "error": str(e)}, status_code=400)
    return JSONResponse({"ok": True})
# --------------------------------------------------------------------------- #


# ---- DATA-REPLAY DVR endpoints -------------------------------------------- #
@app.get("/results")
async def list_results() -> JSONResponse:
    """List saved results CSV files (newest first)."""
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    files = sorted((p.name for p in RESULTS_DIR.glob("results-*.csv")), reverse=True)
    return JSONResponse({"results": files})


@app.get("/results/{name}")
async def get_result(name: str):
    """Download one results CSV."""
    from fastapi.responses import Response
    safe = Path(name).name
    path = RESULTS_DIR / safe
    if not path.exists() or not safe.startswith("results-") or not safe.endswith(".csv"):
        return Response(status_code=404)
    return Response(
        path.read_bytes(),
        media_type="text/csv",
        headers={"Content-Disposition": f'attachment; filename="{safe}"'},
    )


@app.get("/recordings")
async def list_recordings() -> JSONResponse:
    """List saved session recordings (newest first)."""
    RECORDINGS_DIR.mkdir(parents=True, exist_ok=True)
    files = sorted(
        (p.name for p in RECORDINGS_DIR.glob("reschu-recording-*.json")),
        reverse=True,
    )
    return JSONResponse({"recordings": files})


@app.get("/recordings/{name}")
async def get_recording(name: str) -> JSONResponse:
    """Return a single recording's JSON (the frames), for replay/download."""
    # basic guard against path traversal
    safe = Path(name).name
    path = RECORDINGS_DIR / safe
    if not path.exists() or not safe.startswith("reschu-recording-"):
        return JSONResponse({"error": "not found"}, status_code=404)
    return JSONResponse(_json.loads(path.read_text()))


@app.get("/replay")
async def replay_page() -> HTMLResponse:
    """The replay viewer page (reuses the main UI in replay mode)."""
    return HTMLResponse(_REPLAY_HTML)
# --------------------------------------------------------------------------- #


def _boat_payload(boat, world) -> dict:
    """State for one boat. Perceived fields drive the map; true_* are flagged as
    ground truth for the researcher panel only."""
    return {
        "id": boat.id,
        "x": boat.position.x,
        "y": boat.position.y,
        "hx": boat.heading.x,
        "hy": boat.heading.y,
        "identified": boat.identified,
        "preview_video": boat.preview_video,
        "perceived_class": boat.perceived_class.value,   # operator view
        "threat_tier": boat.threat_tier.value if boat.threat_tier else None,
        "id_attempts": boat.id_attempts,
        "correctly_identified": boat.is_correctly_identified(),
        "left_grid": boat.left_grid,
        # --- ground truth: researcher panel only, never drawn on the map ---
        "truth": {
            "true_class": boat.true_class.value,
            "behavior": boat.behavior.value,
        },
    }


def _usv_target_point(usv, world):
    """The point this USV is heading toward, for ETA:
      - manual USV: its operator-drawn destination, else the boat it's intercepting
      - agent USV : the boat its policy is currently working (assigned_target_id)
    Returns a Vec2-like (has .x/.y) or None if it isn't heading anywhere."""
    if usv.mode.value == "manual":
        if usv.manual_destination is not None:
            return usv.manual_destination
        if usv.intercept_target_id is not None:
            b = world.boat(usv.intercept_target_id)
            if b is not None and not b.left_grid:
                return b.position
        return None
    # agent USV: its assigned boat
    if usv.assigned_target_id is not None:
        b = world.boat(usv.assigned_target_id)
        if b is not None and not b.left_grid:
            return b.position
    return None


def _usv_eta_min(usv, world):
    """Estimated minutes for this USV to reach its target, at its current speed.
    None if it has no target or isn't moving. Uses the same knots->units/min
    scale as movement (UNITS_PER_KNOT_MIN)."""
    target = _usv_target_point(usv, world)
    if target is None:
        return None
    speed = usv.effective_speed_knots() * UNITS_PER_KNOT_MIN  # grid units per min
    if speed <= 0:
        return None
    dist = usv.position.distance_to(target)
    return dist / speed


def _boat_video_key(boat, scenario: str = "front") -> str:
    """The camera-clip key for a boat: '{type}_{scenario}'. `scenario` is 'front'
    (boat approaching head-on) or 'crossing' (boat crossing in front). Enemies
    split by threat tier (low/med/high)."""
    from ..types import Classification, Behavior, threat_for_behavior, ThreatTier
    cls = boat.true_class
    if cls is Classification.CIVILIAN:
        base = "civilian"
    elif cls is Classification.FRIENDLY:
        base = "friendly"
    else:
        tier = threat_for_behavior(boat.behavior, boat.speed_knots())
        base = ("high_enemy" if tier is ThreatTier.HIGH
                else "medium_enemy" if tier is ThreatTier.MEDIUM
                else "low_enemy")
    return f"{base}_{scenario}"


def _manual_usv_id(world) -> str:
    """The id of the current MANUAL USV (classify / move_to / set_speed target)."""
    for u in world.usvs:
        if u.mode.value == "manual" and not u.left_grid:
            return u.id
    return ""


def _usv_activity(usv, world) -> str:
    """A short label of what a USV is doing right now, for the timestep log."""
    if getattr(usv, "eliminated", False):
        return "eliminated"
    if usv.left_grid:
        return "off_grid"
    if usv.rtb:
        return "returning_to_base"
    if usv.mode.value == "manual":
        if usv.manual_destination is not None:
            return "manual_en_route_to_point"
        if usv.intercept_target_id:
            return f"manual_intercepting_{usv.intercept_target_id}"
        return "manual_holding"
    # agent modes
    if usv.circling_since_min is not None and usv.assigned_target_id:
        return f"circling_{usv.assigned_target_id}"
    if usv.assigned_target_id:
        tgt = world.boat(usv.assigned_target_id)
        if tgt is not None and tgt.identified and tgt.perceived_class.value == "friendly":
            return f"escorting_{usv.assigned_target_id}"
        return f"seeking_{usv.assigned_target_id}"
    return "patrolling"


def _usv_seen_boat(usv, world):
    """The boat this USV currently 'sees' on camera. A video plays for the
    scenarios we have footage for, chosen by the boat's motion relative to the USV.

    For the nearest boat within the camera detection distance (1.5x the ID range),
    the boat must be IN FRONT of the USV (within +/-45 deg of its heading). Then:
      * APPROACHING head-on (heading toward the USV)  -> '{type}_front' clip.
      * CROSSING (heading roughly perpendicular)      -> '{type}_crossing' clip.
      * RECEDING (moving away from the USV)            -> '{type}_away' clip.
      * BEHIND the USV, facing/approaching it          -> '{type}_behind' clip.
      * BEHIND the USV, moving away from it             -> '{type}_behind_away' clip.
      * off to the side, or behind+crossing            -> no clip.
    """
    import math
    if usv.left_grid:
        return None
    det = identify_range(world.grid) * 1.5
    FRONT_COS = math.cos(math.radians(45))   # ~0.707 : +/-45 deg forward cone
    APPROACH_MIN = 0.35                       # closing dot above this = approaching
    CROSS_MAX = 0.5                           # |closing dot| below this = crossing

    best, bestd = None, det
    for b in world.boats:
        if b.left_grid:
            continue
        d = usv.position.distance_to(b.position)
        if d <= bestd:
            best, bestd = b, d
    if best is None:
        return None

    # geometry gate: which sector is the boat in relative to the USV heading?
    #   FRONT cone (+/-45 deg of heading): classify motion -> front/crossing/away
    #   REAR  cone (+/-45 deg of the OPPOSITE of heading): we only have the boat-
    #         facing/approaching clip -> 'behind' (other rear motions: no clip yet)
    #   sides: no clip.
    to_boat = best.position - usv.position
    dist = to_boat.length()
    if dist < 1e-6:
        return None
    uh = usv.heading.normalized()
    dir_to_boat = Vec2(x=to_boat.x / dist, y=to_boat.y / dist)
    fwd_dot = uh.x * dir_to_boat.x + uh.y * dir_to_boat.y   # +1 ahead, -1 behind

    bh = best.heading.normalized()
    dir_boat_to_usv = Vec2(x=-dir_to_boat.x, y=-dir_to_boat.y)
    # closing component: +1 = boat heading straight at USV, 0 = perpendicular, -1 = away
    closing = bh.x * dir_boat_to_usv.x + bh.y * dir_boat_to_usv.y

    if fwd_dot >= FRONT_COS:
        # boat is IN FRONT
        if closing > APPROACH_MIN:
            scenario = "front"        # coming toward the USV
        elif abs(closing) <= CROSS_MAX:
            scenario = "crossing"     # moving across the field of view
        else:
            scenario = "away"         # moving away from the USV (receding)
    elif fwd_dot <= -FRONT_COS:
        # boat is BEHIND. We have facing/approaching and moving-away rear clips.
        if closing > APPROACH_MIN:
            scenario = "behind"        # behind the USV, facing/approaching it
        elif closing < -CROSS_MAX:
            scenario = "behind_away"   # behind the USV, moving away from it
        else:
            scenario = "behind_crossing"  # behind the USV, moving across the view
    else:
        # boat is OFF TO THE SIDE. All three side motions now have footage.
        if closing > APPROACH_MIN:
            scenario = "side_approaching"  # off to the side, heading toward the USV
        elif abs(closing) <= CROSS_MAX:
            scenario = "side_crossing"     # moving across the field of view, off to the side
        else:
            scenario = "side_away"         # off to the side, moving away from the USV

    return {"boat_id": best.id, "video": _boat_video_key(best, scenario)}


def _usv_payload(usv, world) -> dict:
    dest = usv.manual_destination
    eta = _usv_eta_min(usv, world)
    return {
        "id": usv.id,
        "x": usv.position.x,
        "y": usv.position.y,
        "hx": usv.heading.x,
        "hy": usv.heading.y,
        "mode": usv.mode.value,
        "stationary": usv.stationary,
        "speed_knots": round(usv.effective_speed_knots(), 1),
        # active operator-drawn course (manual USV heading to this point), or None
        "destination": ({"x": dest.x, "y": dest.y} if dest is not None else None),
        # estimated minutes to reach its target (None if not heading anywhere)
        "eta_min": (round(eta, 2) if eta is not None else None),
        # Health & Status fields
        "fuel_pct": round(usv.fuel_pct, 1),
        "camera": _usv_seen_boat(usv, world),
        "comms_state": usv.comms_state.value,
        # engage-agent toggle is ON for agentic (LLM/MDP) USVs, OFF for manual.
        "agent_on": usv.mode.is_agent(),
        "rtb": usv.rtb,
        "left_grid": usv.left_grid,
    }


def _manual_links(world) -> list[dict]:
    """Links from the MANUAL USV to every boat currently within its ID range that
    is not yet correctly identified. Each link persists (recomputed each tick)
    until the boat is correctly identified or leaves the range. The operator uses
    these to see which contacts are identifiable right now, and picks which to
    classify first — several links can be active at once."""
    manual = next((u for u in world.usvs if u.mode.value == "manual"), None)
    if manual is None or manual.rtb or manual.left_grid:
        return []
    links = []
    for b in world.boats:
        if b.left_grid or b.is_correctly_identified():
            continue
        d = manual.position.distance_to(b.position)
        if d <= identify_range(world.grid):
            links.append({"usv_id": manual.id, "boat_id": b.id, "distance": round(d, 2)})
    return links


def _agent_links(world) -> list[dict]:
    """Links from each AGENT USV to the boat it is currently working (its
    assigned target). The link persists until the agent finishes its whole
    routine on that boat and releases it (assigned_target_id clears)."""
    links = []
    for u in world.usvs:
        if not u.mode.is_agent() or u.rtb or u.left_grid:
            continue
        tid = u.assigned_target_id
        if tid is None:
            continue
        b = world.boat(tid)
        if b is None or b.left_grid:
            continue
        d = u.position.distance_to(b.position)
        links.append({"usv_id": u.id, "boat_id": b.id, "distance": round(d, 2)})
    return links


def _state_payload(world) -> dict:
    # capture the pre-identification camera clip for each boat: for every USV,
    # what it currently sees; if that boat is still unidentified, remember the
    # clip so the operator can replay it after ID (from the Contacts panel).
    for u in world.usvs:
        seen = _usv_seen_boat(u, world)
        if seen is None:
            continue
        b = world.boat(seen["boat_id"])
        if b is not None and not b.identified:
            b.preview_video = seen["video"]
    return {
        "type": "state",
        "now_min": round(world.mission_time_min, 2),
        "mission_length_min": round(MISSION_LENGTH_MIN, 2),
        "grid": {"width": world.grid.width, "height": world.grid.height},
        "identify_range": identify_range(world.grid),
        "danger_zone": danger_zone_radius(world.grid),
        "usvs": [_usv_payload(u, world) for u in world.usvs],
        "boats": [_boat_payload(b, world) for b in world.boats],
        "manual_links": _manual_links(world),
        "agent_links": _agent_links(world),
    }


@app.websocket("/ws")
async def ws(sock: WebSocket) -> None:
    await sock.accept()

    # build the world from the saved scenario config (falls back to the default
    # simple scenario if the config is somehow invalid)
    try:
        world = world_from_config(_CURRENT_CONFIG)
    except Exception:  # noqa: BLE001
        world = simple_world()

    # Playback pacing. The slider is the ONLY speed control: at 1.0 the sim runs
    # in REAL TIME (1 real second = 1 simulation second); >1 speeds up, <1 slows
    # down. We advance 1 simulation second per tick and wait 1 real second per
    # tick (divided by the slider multiplier), so slider=1 is true real-time.
    DT_MIN = 1.0 / 60.0        # 1 simulation SECOND advanced per tick
    TICK_SECONDS = 1.0         # 1 real second per tick at slider 1x -> real time

    engine = SimulationEngine(world, dt_min=DT_MIN, seed=42, assign_at_start=True)

    # a lock so operator actions and the tick loop don't race on the world
    lock = asyncio.Lock()

    # The live speed multiplier driven by the UI slider. 1.0 = real time; >1 runs
    # faster (shorter delay per tick), <1 runs slower. Stored in a one-element
    # list so the receive loop can mutate it while the tick loop reads it.
    speed_mult = [1.0]
    # pause flag driven by the PAUSE button; while True the engine holds.
    paused = [False]

    # DATA-REPLAY DVR: accumulate every tick's state so the run can be replayed.
    recorded_frames: list = []
    timestep_log: list = []      # one row per USV per tick
    operator_log: list = []      # one row per operator action
    saved = {"done": False}

    def _log_op(usv_id: str, action: str, detail: str = "") -> None:
        """Record one operator action with the mission time and the USV's mode."""
        w = engine.world
        u = w.usv(usv_id) if usv_id else None
        operator_log.append({
            "mission_min": round(w.mission_time_min, 4),
            "usv_id": usv_id or "",
            "usv_mode": (u.mode.value if u is not None else ""),
            "action": action,
            "detail": detail,
        })

    # message box: a queue of messages to push to the client, a periodic-status
    # counter (which USV reports next, and how long since the last report), and a
    # dedicated RNG so replies/status read naturally but reproducibly.
    msg_queue: list = []
    msg_rng = _random.Random(1234)
    msg_state = {"next_usv": 0, "ticks_since": 0, "was_oor": set()}
    MSG_EVERY_TICKS = 8    # a status report roughly every ~8 ticks (feed flows continuously)

    def _finalize_recording(extra: dict | None = None) -> str | None:
        if saved["done"]:
            return None
        saved["done"] = True
        # Always write the results CSVs for this run (independent of REC).
        try:
            saved["csv"] = _write_results_csv(
                world, _CURRENT_CONFIG, timestep_log, operator_log)
        except Exception:  # noqa: BLE001 — logging must never break the run
            saved["csv"] = None
        # The frame-by-frame recording only if REC captured frames.
        return _save_recording(recorded_frames)

    async def on_tick(w) -> None:
        # per-USV per-tick log row (mode + what it's doing right now)
        t = round(w.mission_time_min, 4)
        for u in w.usvs:
            timestep_log.append({
                "mission_min": t,
                "usv_id": u.id,
                "mode": u.mode.value,
                "x": round(u.position.x, 3),
                "y": round(u.position.y, 3),
                "speed_knots": round(u.effective_speed_knots(), 2),
                "comms_state": u.comms_state.value,
                "fuel_pct": round(u.fuel_pct, 1),
                "assigned_target": u.assigned_target_id or "",
                "activity": _usv_activity(u, w),
            })

        # periodic incoming status report from the USVs (round-robin), flowing
        # continuously in the incoming feed.
        #
        # Comms gating: the moment a USV goes OUT OF RANGE, it sends one final
        # "comms lost" message, then stays silent until it recovers. A USV that is
        # out of range is skipped for the ordinary round-robin status reports.
        oor_now = {u.id for u in w.usvs
                   if not u.left_grid and u.comms_state.value == "out_of_range"}
        # newly out of range this tick -> emit one comms-lost notice each
        for u in w.usvs:
            if u.id in oor_now and u.id not in msg_state["was_oor"]:
                msg_queue.append(_messages.make_incoming(u, w))  # says "comms lost"
        # any USV that recovered drops out of the set so it can report again
        msg_state["was_oor"] = oor_now

        live = [u for u in w.usvs
                if not u.left_grid and u.comms_state.value != "out_of_range"]
        if live:
            msg_state["ticks_since"] += 1
            if msg_state["ticks_since"] >= MSG_EVERY_TICKS:
                msg_state["ticks_since"] = 0
                idx = msg_state["next_usv"] % len(live)
                msg_state["next_usv"] = idx + 1
                msg_queue.append(_messages.make_incoming(live[idx], w))

        payload = _state_payload(w)
        payload["paused"] = paused[0]
        if msg_queue:
            payload["messages"] = list(msg_queue)
            msg_queue.clear()
        recorded_frames.append(payload)   # log this frame for replay
        async with lock:
            await sock.send_json(payload)
        # wait one real second per tick, divided by the slider multiplier
        # (slider 1.0 = real time)
        await asyncio.sleep(TICK_SECONDS / max(0.01, speed_mult[0]))
        # while paused, hold here (re-sending the current frame) so the engine
        # doesn't advance until the operator resumes.
        while paused[0]:
            async with lock:
                await sock.send_json({**_state_payload(w), "paused": True})
            await asyncio.sleep(0.1)

    # receive operator actions concurrently with the sim loop
    async def receive_actions() -> None:
        try:
            while True:
                msg = await sock.receive_json()
                action = msg.get("action")
                if action == "classify":
                    await _handle_classify(world, lock, msg, sock)
                    _log_op(_manual_usv_id(world),
                            "classify",
                            f"{msg.get('boat_id','')} -> {msg.get('perceived','')}")
                elif action == "move_to":
                    await _handle_move_to(world, lock, msg)
                    _log_op(_manual_usv_id(world), "move_to",
                            f"({msg.get('x','')},{msg.get('y','')})")
                elif action == "set_speed":
                    await _handle_set_speed(world, lock, msg)
                    _log_op(_manual_usv_id(world), "set_speed",
                            f"{msg.get('knots','')} knt")
                elif action == "change_target":
                    await _handle_change_target(world, lock, msg)
                    _log_op(msg.get("usv_id",""), "change_target",
                            str(msg.get("boat_id","")))
                # ---- DEV SPEED CONTROL (remove before deployment) ---------- #
                elif action == "set_sim_speed":
                    try:
                        speed_mult[0] = float(msg.get("mult", 1.0))
                    except (TypeError, ValueError):
                        pass
                elif action == "set_paused":
                    paused[0] = bool(msg.get("paused", False))
                elif action == "set_rtb":
                    uid = msg.get("usv_id")
                    async with lock:
                        u = engine.world.usv(uid)
                        if u is not None and not u.left_grid:
                            u.rtb = True
                            # disengage immediately: drop any assignment / circle
                            # / escort / intercept so it heads straight for the
                            # nearest edge instead of finishing its current job.
                            u.assigned_target_id = None
                            u.circling_since_min = None
                            u.intercept_target_id = None
                            u.manual_destination = None
                    _log_op(uid or "", "rtb", "return to base")
                # ------------------------------------------------------------ #
                elif action == "send_message":
                    text = (msg.get("text") or "").strip()
                    to = msg.get("to") or "ALL USV"
                    if text:
                        async with lock:
                            w = engine.world
                            # echo the operator's message, then the USV reply/ies
                            out = [_messages.operator_message(text, to, w)]
                            out += _messages.replies_to(text, to, w, msg_rng)
                        await sock.send_json({"type": "messages", "messages": out})
                        _log_op("", "message", f"to {to}: {text}")
                # ------------------------------------------------------------ #
                elif action == "start":
                    start_event.set()   # operator pressed Start Simulation
        except WebSocketDisconnect:
            engine.stop()
            start_event.set()   # unblock the waiter so the handler can clean up

    # Send the initial scene (frozen at t=0) so the operator can see the setup
    # and arm recording, then wait for the Start action before running the sim.
    start_event = asyncio.Event()
    async with lock:
        intro = _state_payload(world)
        intro["awaiting_start"] = True
        await sock.send_json(intro)

    recv_task = asyncio.create_task(receive_actions())
    await start_event.wait()          # block here until "start" (or disconnect)

    # if the socket disconnected before Start was pressed, clean up and exit
    if recv_task.done():
        engine.stop()
        recv_task.cancel()
        return

    sim_task = asyncio.create_task(
        engine.run(
            duration_min=MISSION_LENGTH_MIN, realtime_factor=0.0, on_tick=on_tick
        )
    )
    try:
        # when the sim finishes its mission length, tell the browser it's over
        await sim_task
        async with lock:
            final = _state_payload(world)
            final["type"] = "state"
            final["mission_complete"] = True
            # DVR: save the recording and tell the browser its filename
            rec_name = _finalize_recording()
            if rec_name:
                final["recording"] = rec_name
            if saved.get("csv"):
                final["results_csv"] = saved["csv"]
            await sock.send_json(final)
        # keep the socket open so the operator can still read the final state /
        # send late classify actions; end when they disconnect
        await recv_task
    except (WebSocketDisconnect, asyncio.CancelledError):
        pass
    finally:
        engine.stop()
        _finalize_recording()   # save if not already (early disconnect / cancel)
        for t in (sim_task, recv_task):
            t.cancel()


async def _handle_set_speed(world, lock, msg) -> None:
    """Operator set the manual USV's speed via the stepper. `knots` is the new
    absolute speed (the stepper already stepped it by +/-0.5); the model clamps
    it to a sensible range."""
    knots = msg.get("knots")
    if knots is None:
        return
    manual = next((u for u in world.usvs if u.mode.value == "manual"), None)
    if manual is None:
        return
    async with lock:
        manual.set_operator_speed(float(knots))


async def _handle_change_target(world, lock, msg) -> None:
    """Operator asked an AGENT USV to change its target. The agent auto-picks a
    different un-identified boat (it releases the current one; the operator does
    NOT choose which). `usv_id` names the agent USV."""
    usv_id = msg.get("usv_id")
    if usv_id is None:
        return
    async with lock:
        reassign_usv(world, usv_id)


async def _handle_move_to(world, lock, msg) -> None:
    """Operator drew a move for the manual USV: set its destination point. The
    USV then travels toward it each tick (see manual_step)."""
    x, y = msg.get("x"), msg.get("y")
    if x is None or y is None:
        return
    manual = next((u for u in world.usvs if u.mode.value == "manual"), None)
    if manual is None:
        return
    async with lock:
        manual.manual_destination = world.grid.clamp(Vec2(x=float(x), y=float(y)))


async def _handle_classify(world, lock, msg, sock) -> None:
    """Operator classifies a contact using the manual USV (must be in range).
    `perceived` is one of unknown/friendly/civilian/enemy; enemies also carry a
    tier for display but tier doesn't change the class recorded."""
    boat_id = msg.get("boat_id")
    perceived = msg.get("perceived", "")
    # find the manual USV to attribute the action to
    manual = next((u for u in world.usvs if u.mode.value == "manual"), None)
    if manual is None:
        return
    try:
        as_class = Perception(perceived)
    except ValueError:
        return
    async with lock:
        ok = manual_identify(world, manual.id, boat_id, as_class=as_class)
        result = _state_payload(world)
        result["type"] = "state"
        result["last_action"] = {
            "boat_id": boat_id, "perceived": perceived, "ok": ok,
        }
        await sock.send_json(result)
