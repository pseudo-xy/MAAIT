"""USV decision agents ("policies").

An AGENT-mode USV is driven by a *policy* — the "brain" that makes the choices:
which boat to go after, what speed and direction, when to identify, and whether
to circle or escort after identification. The *mechanics* of carrying those out
(how to travel to a point, how to orbit) live in usv_movement.py and are shared
by every policy.

This is the seam where trained agents plug in. Today there is one working policy,
SCRIPTED (the rule-based baseline). LLM and MDP policies are stubs: they exist so
the structure is real and the wiring is in place, but they are NOT trained or
connected yet — each currently falls back to the scripted behavior and is clearly
marked as a placeholder.

Each USV chooses its policy via `usv.mode` (USVMode.LLM / USVMode.MDP); MANUAL
USVs are driven by the operator, not a policy.

To add a real agent later:
  * implement `decide()` in LLMPolicy / MDPPolicy (or a new Policy subclass),
  * have it return the USV's next position for this tick (using the helpers in
    usv_movement.py for the actual motion),
  * everything else — the engine loop, identification, logging — stays the same.
"""

from __future__ import annotations

from .models import USV, World
from .observation import Observation, observe
from .types import USVMode, Vec2
from .usv_movement import assigned_agent_step


class Policy:
    """Base class for a USV decision agent.

    A policy decides from a truth-free `Observation` (what the USV perceives) and
    returns where the USV should be after this tick. It may set fields on the USV
    that the rest of the system reads (assigned_target_id, operator_speed_knots,
    circling_since_min) — those represent the agent's choices.

    Ground-truth hardening: real agents override `act(usv, obs, dt_min)`, which is
    handed ONLY the truth-free observation — never the World. An agent therefore
    *cannot* reach a boat's true class, behavior, or true threat tier even by
    accident: the world object is not in scope inside `act()`. This upgrades the
    guarantee from "agents don't read truth" to "agents can't read truth", which
    matters once real LLM/MDP agents are written.

    (The internal scripted baseline is the one exception — see ScriptedPolicy.)
    """

    name: str = "policy"

    def decide(self, usv: USV, world: World, dt_min: float, now_min: float) -> Vec2:
        """Build the truth-free observation, then act on it. Real agents override
        `act()` (which never sees `world`), NOT this method."""
        obs = observe(usv, world, now_min)
        return self.act(usv, obs, dt_min)

    def act(self, usv: USV, obs: Observation, dt_min: float) -> Vec2:
        """Decide the USV's next position from the truth-free observation ONLY.

        Note there is no `world` parameter by design — an agent's decision must
        not depend on ground truth, and this signature makes that impossible
        rather than merely discouraged. Override this in real LLM/MDP agents.
        """
        raise NotImplementedError


class ScriptedPolicy(Policy):
    """Internal rule-based baseline. NOT a selectable mode — it's the shared
    logic the untrained LLM/MDP stubs currently run on so the sim works.

    Behavior: go to the assigned boat -> once identified, circle a perceived
    enemy for a fixed time or escort a perceived friendly/civilian off the grid
    -> release and let the engine re-assign. When the real LLM/MDP agents are
    implemented, they replace this fallback with their own decisions.

    Exception to the world-hiding rule: as an INTERNAL mechanics component (not a
    competing agent under study), the baseline overrides `decide()` directly so it
    can use the shared movement helpers, which take `world` to carry out motion.
    It still reads no ground truth — assigned_agent_step and usv_movement use
    perceived class only (verified: no true_class/behavior access anywhere in the
    movement layer). `world` is used here for MECHANICS (moving, circling), never
    to see a boat's true identity.
    """

    name = "scripted"

    def decide(self, usv: USV, world: World, dt_min: float, now_min: float) -> Vec2:
        return assigned_agent_step(usv, world, dt_min, now_min)


class LLMPolicy(Policy):
    """LLM-driven agent — NOT TRAINED / CONNECTED YET (stub).

    When implemented, override `act(usv, obs, dt_min)`: build a description of the
    USV's view from `obs` (nearby boats, their PERCEIVED classes, distances, etc.
    — obs has no ground truth), send it to an LLM, parse the LLM's chosen action
    (target boat, speed, next move, identify / circle / escort), and return the
    next position. Because `act()` never receives `world`, the LLM cannot be fed a
    boat's true identity even by mistake.

    For now it falls back to the scripted baseline so the sim still runs.
    """

    name = "llm"

    def __init__(self) -> None:
        self._fallback = ScriptedPolicy()

    def decide(self, usv: USV, world: World, dt_min: float, now_min: float) -> Vec2:
        # TODO: implement act(usv, obs, dt_min) with a real LLM decision and drop
        # this override. Placeholder = scripted baseline so the sim runs.
        return self._fallback.decide(usv, world, dt_min, now_min)


class MDPPolicy(Policy):
    """MDP-driven agent — NOT TRAINED / CONNECTED YET (stub).

    When implemented, override `act(usv, obs, dt_min)`: map `obs` (the truth-free
    view) to the MDP's state representation, look up the trained policy's action
    for that state (which boat, speed, direction, identify / circle / escort), and
    return the next position. Because `act()` never receives `world`, the MDP's
    state can only be built from perceived information — ground truth is out of
    reach by construction.

    For now it falls back to the scripted baseline so the sim still runs.
    """

    name = "mdp"

    def __init__(self) -> None:
        self._fallback = ScriptedPolicy()

    def decide(self, usv: USV, world: World, dt_min: float, now_min: float) -> Vec2:
        # TODO: implement act(usv, obs, dt_min) with the trained MDP lookup and
        # drop this override. Placeholder = scripted baseline so the sim runs.
        return self._fallback.decide(usv, world, dt_min, now_min)


# One shared instance of each policy, chosen by the USV's mode.
_SCRIPTED = ScriptedPolicy()
_POLICIES: dict[USVMode, Policy] = {
    USVMode.LLM: LLMPolicy(),
    USVMode.MDP: MDPPolicy(),
}


def policy_for(usv: USV) -> Policy:
    """Return the policy that drives this (agent-mode) USV, based on its mode.
    Falls back to the internal scripted baseline for anything unexpected."""
    return _POLICIES.get(usv.mode, _SCRIPTED)
