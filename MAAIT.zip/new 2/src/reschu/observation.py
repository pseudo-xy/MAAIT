"""The truth-free observation an agent is allowed to see.

Ground truth — a boat's `true_class`, `behavior`, `standoff_speed`, and the true
threat tier — lives on the engine side and is used ONLY to reveal identity through
identification and to score results. No agent's decision-making may touch it.

This module builds the operator's-eye view: for a given USV, what it perceives
about the world. Agents (LLM / MDP / the scripted baseline) receive an
`Observation` and decide from that alone, so every agent plays by the same rules
and the comparison is fair. When the real LLM/MDP agents are implemented, this is
the exact, already-truth-free input they consume.

What's included (perceived only):
  * the USV's own state (position, heading, speed, mode, comms, current target)
  * each boat's id, position, distance, whether it's been identified, and its
    PERCEIVED class (unknown until identified) and shown threat tier
  * the grid bounds
Deliberately excluded: any boat's true_class, behavior, standoff_speed, or true
tier.
"""

from __future__ import annotations

from dataclasses import dataclass

from .models import USV, World
from .types import CommsState, Perception, ThreatTier, USVMode, Vec2


@dataclass
class BoatView:
    """What a USV perceives about one boat — no ground truth."""
    id: str
    position: Vec2
    distance: float               # from the observing USV
    identified: bool
    perceived_class: Perception   # unknown until identified
    threat_tier: ThreatTier | None  # only shown once a correct enemy ID is made
    being_escorted: bool
    left_grid: bool


@dataclass
class SelfView:
    """The observing USV's own state."""
    id: str
    position: Vec2
    heading: Vec2
    speed_knots: float
    mode: USVMode
    comms_state: CommsState
    assigned_target_id: str | None


@dataclass
class Observation:
    """Everything one USV is allowed to know this tick. Truth-free by
    construction — an agent physically cannot read a boat's true identity from
    this object."""
    now_min: float
    grid_width: float
    grid_height: float
    me: SelfView
    boats: list[BoatView]

    def boat(self, boat_id: str) -> BoatView | None:
        return next((b for b in self.boats if b.id == boat_id), None)

    def unidentified(self) -> list[BoatView]:
        return [b for b in self.boats if not b.identified and not b.left_grid]

    def perceived_enemies(self) -> list[BoatView]:
        return [
            b for b in self.boats
            if b.identified and b.perceived_class is Perception.ENEMY and not b.left_grid
        ]

    def perceived_nonenemies(self) -> list[BoatView]:
        return [
            b for b in self.boats
            if b.identified and b.perceived_class is not Perception.ENEMY and not b.left_grid
        ]


def observe(usv: USV, world: World, now_min: float) -> Observation:
    """Build the truth-free observation for `usv` from the world state."""
    boats = [
        BoatView(
            id=b.id,
            position=b.position,
            distance=usv.position.distance_to(b.position),
            identified=b.identified,
            perceived_class=b.perceived_class,
            threat_tier=b.threat_tier,
            being_escorted=b.being_escorted,
            left_grid=b.left_grid,
        )
        for b in world.boats
    ]
    me = SelfView(
        id=usv.id,
        position=usv.position,
        heading=usv.heading,
        speed_knots=usv.effective_speed_knots(),
        mode=usv.mode,
        comms_state=usv.comms_state,
        assigned_target_id=usv.assigned_target_id,
    )
    return Observation(
        now_min=now_min,
        grid_width=world.grid.width,
        grid_height=world.grid.height,
        me=me,
        boats=boats,
    )
