# RESCHU-MAAIT — USV Mission-Control Simulation

A research prototype simulating an unmanned surface vehicle (USV) mission-control
console on an abstract grid. This repository is the **pure-Python simulation
core** — the logic layer that the web interface will later sit on top of.

## Design principle: logic first, interface second

The mockup deck already specifies *what the interface does*. The hard, testable
part is the simulation underneath, so it is built and verified headless — no
server, no browser — before any UI is added.

## What's here so far

| Module | Responsibility |
| --- | --- |
| `types.py` | Vocabulary (classifications, behaviors, threat tiers, comms states, USV modes) + 2-D geometry |
| `models.py` | Entities: `Grid`, `Boat`, `USV`, `CommsSchedule`, `World` |
| `behaviors.py` | Autonomous boat movement, one strategy per behavior |
| `identification.py` | Proximity + mode rules for identifying boats |
| `engine.py` | `tick()` (state advance) and `run()` (asyncio loop) |
| `scenario.py` | A demo world matching the mockup |
| `demo.py` | Runnable headless demo |

## Core rules encoded

**Boat behaviors (end-goal driven):** every boat heads toward an end goal set by
its type and picks a new one on arrival — aggressive enemies attack a USV (aim at
the nearest USV, re-aimed each tick); standoff enemies head to a far corner of
the map; civilians travel in a straight line from their start; friendlies head to
random grids. Speeds: civilian 5 kn, aggressive 10 kn, standoff 4 or 8 kn,
friendly 8 kn.

**Truth vs. perception:** every boat has a *true* type known to the engine from
t=0 and a *perceived* state shown to the operator. All boats start as UNKNOWN.

**Identification:** agent-mode USVs identify nearby boats automatically; manual
USVs require the operator to bring the USV close and explicitly identify.

**Threat tier:** derived from behavior and speed on correct identification —
aggressive → High, standoff at 8 kn → Medium, standoff at 4 kn → Low. A
*misidentification* (labelling a boat as the wrong class) records the label for
display but does not change the boat's true behavior, and shows no threat tier;
the model counts identification attempts so we can study how many it takes to get
the label right. Revisable at any time.

**Comms:** each USV's per-state schedule (start + duration) drives its comms
signal, matching the admin-screen configuration and the Health & Status panel.

## Setup (uv)

```bash
uv venv
uv pip install -e ".[dev]"
```

## Run the demo

```bash
uv run python -m reschu.demo
```

This prints the mission log and writes **`results/demo_run.csv`** (overwritten
each run) — one row per boat per timestep with position, nearest agent USV,
distance, identification status, and perceived class/threat.

## Run the tests

```bash
uv run pytest
```

This runs the suite and writes **`results/pytest_results.csv`** (overwritten each
run) — one row per test with its name, outcome, and duration.


## Noted for later

- **Operator click logging.** Every operator click should be logged (what was
  clicked, when). This will live in the interaction layer once it exists; the
  intent is a per-session click log for later analysis.

## Web UI (simplified scenario)

A first operator-console UI for the simplified 6-boat scenario, matching the
mockup's tactical map. It runs the simulation server-side and streams each tick
to the browser over a WebSocket; the browser draws the map and sends operator
classify actions back.

Run it:

```
uv pip install -e ".[web]"      # fastapi + uvicorn (quote the brackets in zsh)
uv run uvicorn reschu.web.server:app --reload
# then open http://127.0.0.1:8000
```
